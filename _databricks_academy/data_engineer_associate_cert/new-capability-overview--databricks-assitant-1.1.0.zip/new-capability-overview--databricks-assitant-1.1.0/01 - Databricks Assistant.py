# Databricks notebook source
# MAGIC %md
# MAGIC 
<div style="text-align: center; line-height: 0; padding-top: 9px;">
  <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning">
</div>


# COMMAND ----------

# MAGIC %md
# MAGIC # New Capability Overview: Databricks Assistant
# MAGIC
# MAGIC In this demo, we will showcase how Databricks Assistant revolutionizes the coding experience by demonstrating its capabilities in generating, transforming, completing, debugging, and explaining code examples across various languages supported on the Databricks platform.
# MAGIC
# MAGIC **Learning Objectives:**
# MAGIC
# MAGIC By the end of this demo, you will:
# MAGIC
# MAGIC + Understand how Databricks Assistant enhances the coding workflow.
# MAGIC
# MAGIC + Explore the functionalities of Databricks Assistant, including code generation, transformation, completion, debugging, and explanation.
# MAGIC
# MAGIC + Learn how to leverage Databricks Assistant to write code more efficiently and effectively in your data science and engineering projects.

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Requirements 
# MAGIC + In order to access the Databricks Assistant, you will need administrator approval to enable  your Workspaces.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Classroom Setup
# MAGIC The first step is to run a setup script. This script will define the required configuration variables that are scoped to each user. Additionally, it will create a catalog and a schema that we are going to use in this demo.

# COMMAND ----------

# MAGIC %run ./Includes/Classroom-Setup-01

# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC
# MAGIC ### Other Conventions
# MAGIC
# MAGIC Run code block below to view necessary details that we will need in this course. Note the **catalog name** and schema name that we are going to use to create tables and later inspect the lineage graphs.
# MAGIC
# MAGIC In addition, as you progress through this course, you will see various references to the object **`DA`**. This object is provided by Databricks Academy and is part of the curriculum and not part of a Spark or Databricks API. For example, the **`DA`** object exposes useful variables such as your username and various paths to the datasets in this course as seen here bellow. In this course we are going to use UI mostly, therefore, we are not going to need them for now.

# COMMAND ----------

print(f"Username:          {DA.username}")
print(f"Catalog Name:      {DA.catalog_name}")
print(f"Schema Name:       {DA.schema_name}")
print(f"Working Directory: {DA.paths.working_dir}")
print(f"Datasets Location: {DA.paths.datasets}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## What is the Assistant and why use it?
# MAGIC + The Databricks Assistant is your data-focused AI-pair programmer for notebooks, queries, and files
# MAGIC + It helps users answer questions about their code, and increase productivity by making it faster to develop with Databricks
# MAGIC + Users can benefit from the capabilities of LLMs, including finding new ways to do things that are faster, more efficient, and easier
# MAGIC + Reduces the number of times a user will have to leave the notebook, such as reading documentation, knowledge bases, etc...
# MAGIC + Easily write code without needing to know about every syntax or feature of a language
# MAGIC + Automatically generate comments and documentation about your code

# COMMAND ----------

# MAGIC %md
# MAGIC ## Task 1: Generating Code for Carat vs. Price Analysis
# MAGIC Let's start by generating some code. Imagine you want to create a dataset and perform some data visualization. With Databricks Assistant, you can simply describe your task in English, and it will generate the Python code for you.
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC **Instructions:**
# MAGIC
# MAGIC **Step 1:** Execute the following Python code to generate a synthetic dataset for carat vs. price analysis:

# COMMAND ----------

import pandas as pd
import numpy as np

# Set the seed for reproducibility
np.random.seed(42)

# Generate random data for the dataframe
df = pd.DataFrame({'Carat': np.random.uniform(0.2, 3.0, 1000),
                   'Price': np.random.uniform(8000, 2000, 1000) * np.random.uniform(0.2, 3.0, 1000)})

# Save the dataframe to a CSV file
df.to_csv('carat_vs_price_dataset.csv', index=False)

# COMMAND ----------

# MAGIC %md
# MAGIC **Step 2:** Ask Databricks Assistant to Generate Visualization Code
# MAGIC
# MAGIC
# MAGIC **`Prompt:`** `"Import a dataset named 'carat_vs_price_dataset.csv' and create a scatterplot to visualize the relationship between carat and price."`

# COMMAND ----------

# Import the generated code here

# COMMAND ----------

# Import the necessary libraries
#import pandas as pd
import matplotlib.pyplot as plt

# Read the dataset into a dataframe
#df = pd.read_csv("carat_vs_price_dataset.csv")

# Create a scatterplot of carat vs. price
plt.scatter(df["Carat"], df["Price"])
plt.xlabel("Carat")
plt.ylabel("Price")
plt.title("Carat vs. Price Scatterplot")
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ##Task 2: Debug Code
# MAGIC Next, let's see how Databricks Assistant can help us debug code. If you encounter an error in your code, you can ask Databricks Assistant to diagnose the error and suggest fixes.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC **Instructions:**
# MAGIC
# MAGIC **Step 1:** Execute the Code with Error

# COMMAND ----------

# incorrect code
#import pandas as pd

# Load the dataset with the error
#df = pd.read_csv('carat_vs_price_dataset.csv')

df.plot.scatter(x='carat', y='price')

# COMMAND ----------

# MAGIC %md
# MAGIC **Step 2:** Ask Databricks Assistant to Diagnose and Fix the Error
# MAGIC
# MAGIC **`Prompt:`** `"Diagnose the error in above code and suggest a fix."`
# MAGIC
# MAGIC

# COMMAND ----------

#Import the Debugged code here

# COMMAND ----------

#import pandas as pd

# Read the dataset into a DataFrame
#df = pd.read_csv("carat_vs_price_dataset.csv")

# Create a scatterplot of carat vs. price
df.plot.scatter(x='Carat', y='Price')

# COMMAND ----------

# MAGIC %md
# MAGIC ##Task 3: Transform and Optimize Code
# MAGIC In this task, we'll explore how Databricks Assistant can help us optimize code for our carat vs. price dataset. We'll first transform the given Python code into PySpark code, and then optimize it using Databricks Assistant.

# COMMAND ----------

# MAGIC %md
# MAGIC **Instructions:**
# MAGIC
# MAGIC **Step 1:** Ask Databricks Assistant to transform the given pandas code to PySpark and to optimize the code for better performance.
# MAGIC
# MAGIC **`Prompt:`** `Transform the given pandas code to PySpark to apply Min-Max scaling to normalize the 'Carat' and 'Price' columns efficiently.`

# COMMAND ----------

import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# Apply Min-Max scaling to normalize the 'Carat' and 'Price' columns
scaler = MinMaxScaler()
df[['Carat', 'Price']] = scaler.fit_transform(df[['Carat', 'Price']])

# Display the transformed dataframe
print(df.head())

# COMMAND ----------

# Paste code here

# COMMAND ----------

# Import pandas code to PySpark transform code
from sklearn.preprocessing import MinMaxScaler
from pyspark.sql import SparkSession

# Create SparkSession
spark = SparkSession.builder.getOrCreate()

# Load the dataset
spark_df = spark.createDataFrame(df)

# Convert DataFrame to Pandas DataFrame
pandas_df = spark_df.toPandas()

# Apply Min-Max scaling to normalize the 'Carat' and 'Price' columns
scaler = MinMaxScaler()
scaled_values = scaler.fit_transform(pandas_df[['Carat', 'Price']])
pandas_df[['Carat', 'Price']] = scaled_values

# Convert Pandas DataFrame back to Spark DataFrame
df = spark.createDataFrame(pandas_df)

# Display the transformed dataframe
df.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Task 4: Explain Code
# MAGIC Sometimes, you may need help understanding complex code snippets. Databricks Assistant can provide detailed explanations of code, line by line if needed.
# MAGIC
# MAGIC **`Prompt:`** `"Explain this code snippet, line by line."`

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ##Task 5: Utilizing Databricks Assistant in SQL Editor for Visualization
# MAGIC
# MAGIC Let's leverage Databricks Assistant within the SQL editor to create a table with sample data and visualize it. Databricks Assistant can assist us in generating SQL queries and executing visualizations seamlessly.
# MAGIC
# MAGIC **Instructions:**
# MAGIC
# MAGIC + **Step 1:** Navigate to the SQL editor and locate the Assistant icon.
# MAGIC
# MAGIC
# MAGIC + **Step 2:** Ask Databricks Assistant to generate a SQL query for creating a table named "Demo_table" with sample data for visualization:
# MAGIC
# MAGIC
# MAGIC   **`Prompt:`** `Write query to create table "Demo_table", with some sample data in it for visualization and show the table.`
# MAGIC
# MAGIC + **Step 3:** Import the generated SQL query into the SQL editor and execute it to create the table with the specified sample data.
# MAGIC
# MAGIC + **Step 4:** After creating the table, click on the "`+`" icon within the SQL editor and select the "Visualization" option to initiate the visualization process.

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Clean up Classroom
# MAGIC
# MAGIC Run the following cell to remove lessons-specific assets created during this lesson.

# COMMAND ----------

DA.cleanup()

# COMMAND ----------

# MAGIC %md
# MAGIC # Conclusion
# MAGIC
# MAGIC In this Demo on Databricks Assistant, we delve into the exciting world of AI based Coding Assistant. We explore how you can effortlessly perform a variety of tasks using Natural language commands and seamlessly execute code. This cutting-edge tool simplifies the coding process, making it more intuitive and accessible for data professionals and developers.

# COMMAND ----------

# MAGIC %md
# MAGIC 
&copy; 2024 Databricks, Inc. All rights reserved.<br/>
Apache, Apache Spark, Spark and the Spark logo are trademarks of the 
<a href="https://www.apache.org/">Apache Software Foundation</a>.<br/>
<br/><a href="https://databricks.com/privacy-policy">Privacy Policy</a> | 
<a href="https://databricks.com/terms-of-use">Terms of Use</a> | 
<a href="https://help.databricks.com/">Support</a>