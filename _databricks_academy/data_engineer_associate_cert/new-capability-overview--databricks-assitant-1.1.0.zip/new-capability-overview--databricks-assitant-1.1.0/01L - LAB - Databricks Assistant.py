# Databricks notebook source
# MAGIC %md
# MAGIC 
<div style="text-align: center; line-height: 0; padding-top: 9px;">
  <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning">
</div>


# COMMAND ----------

# MAGIC %md
# MAGIC # LAB: Databricks Assistant
# MAGIC
# MAGIC In this Lab, you will learn how to leverage Databricks Assistant to perform various tasks 
# MAGIC
# MAGIC **Lab Outline:**
# MAGIC
# MAGIC In this Lab, you will learn how to use Databricks Assistant to:
# MAGIC
# MAGIC + **Task 1:** Generate Code.
# MAGIC
# MAGIC + **Task 2:** Debug/Fix Code.
# MAGIC
# MAGIC + **Task 3:** Transform Code
# MAGIC
# MAGIC + **Task 4:** Explain Code
# MAGIC
# MAGIC + **Task 5:** Utilizing Databricks Assistant in SQL Editor
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Requirements 
# MAGIC + In order to access the Databricks Assistant, you will need administrator approval to enable  your Workspaces.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Classroom Setup
# MAGIC The first step is to run a setup script. This script will define the required configuration variables that are scoped to each user. Additionally, it will create a catalog and a schema that we are going to use in this demo.

# COMMAND ----------

# MAGIC %run ./Includes/Classroom-Setup-01

# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC
# MAGIC ### Other Conventions
# MAGIC
# MAGIC Run code block below to view necessary details that we will need in this course. Note the **catalog name** and schema name that we are going to use to create tables and later inspect the lineage graphs.
# MAGIC
# MAGIC In addition, as you progress through this course, you will see various references to the object **`DA`**. This object is provided by Databricks Academy and is part of the curriculum and not part of a Spark or Databricks API. For example, the **`DA`** object exposes useful variables such as your username and various paths to the datasets in this course as seen here bellow. In this course we are going to use UI mostly, therefore, we are not going to need them for now.

# COMMAND ----------

print(f"Username:          {DA.username}")
print(f"Catalog Name:      {DA.catalog_name}")
print(f"Schema Name:       {DA.schema_name}")
print(f"Working Directory: {DA.paths.working_dir}")
print(f"Datasets Location: {DA.paths.datasets}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Task 1: Generating Code 
# MAGIC Let's start by generating some code. Imagine you want to create a dataset and perform some data visualization. With Databricks Assistant, you can simply describe your task in English, and it will generate the Python code for you.
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC **Instructions:**
# MAGIC
# MAGIC **Step 1:** Execute the following Python code to generate a synthetic dataset for customer analysis:

# COMMAND ----------

import pandas as pd
import numpy as np

# Set the seed for reproducibility
np.random.seed(42)

# Generate synthetic data for the customer dataset
n_samples = 1000

# Generate random customer IDs
customer_ids = np.arange(1, n_samples + 1)

# Generate random tenure (number of months)
tenure = np.random.randint(1, 61, n_samples)  
# Generate random gender labels (male/female)
gender = np.random.choice(['male', 'female'], n_samples)

# Generate random churn status (1: churned, 0: not churned)
churn = np.random.choice([0, 1], n_samples)

# Create the DataFrame
customer_df = pd.DataFrame({
    'ID': customer_ids,
    'Tenure': tenure,
    'Gender': gender,
    'Churn': churn
})

# Display the first few rows of the dataset
print(customer_df.head())
display(customer_df)

# COMMAND ----------

# MAGIC %md
# MAGIC **Step 2:** Ask Databricks Assistant to Generate Visualization Code
# MAGIC
# MAGIC
# MAGIC **`Prompt:`** `"Import a dataset named 'customer_df' and create a bar chart to visualize the relationship between Tenure and Churn."`

# COMMAND ----------

#Import the generated code here
<FILL_IN>

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ##Task 2: Debug Code
# MAGIC Next, let's see how Databricks Assistant can help us debug code. If you encounter an error in your code, you can ask Databricks Assistant to diagnose the error and suggest fixes.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC **Instructions:**
# MAGIC
# MAGIC **Step 1:** Execute the Code with Error

# COMMAND ----------

# incorrect code
customer_df.plot.scatter(x='tenure', y='churn')

# COMMAND ----------

# MAGIC %md
# MAGIC **Step 2:** Ask Databricks Assistant to Diagnose and Fix the Error
# MAGIC
# MAGIC **`Prompt:`** `"Diagnose the error in above code and suggest a fix."`
# MAGIC
# MAGIC

# COMMAND ----------

#Import the Debugged code here
<FILL_IN>

# COMMAND ----------

# MAGIC %md
# MAGIC ##Task 3: Transform Code
# MAGIC In this task, ypu will explore how Databricks Assistant can help us Tranform code for your dataset.

# COMMAND ----------

# MAGIC %md
# MAGIC **Instructions:**
# MAGIC
# MAGIC **Step 1:** Ask Databricks Assistant to transform the given pandas code to PySpark and to optimize the code for better performance.
# MAGIC
# MAGIC **`Prompt:`** `Transform the given pandas code to PySpark to apply Min-Max scaling to normalize the 'Tenure' and 'Churn' columns efficiently.`

# COMMAND ----------

from sklearn.preprocessing import MinMaxScaler

# Select the 'Tenure' and 'Churn' columns
selected_columns = ['Tenure', 'Churn']
data = customer_df[selected_columns]

# Apply Min-Max scaling to normalize the columns
scaler = MinMaxScaler()
scaled_data = scaler.fit_transform(data)

# Assign the scaled values back to the original dataframe
customer_df[selected_columns] = scaled_data

# Display the first few rows of the updated dataframe
print(customer_df.head())

# COMMAND ----------

# Paste code here
<FILL_IN>

# COMMAND ----------

# MAGIC %md
# MAGIC ##Task 4: Explain Code
# MAGIC Sometimes, you may need help understanding complex code snippets. Databricks Assistant can provide detailed explanations of code, line by line if needed.
# MAGIC
# MAGIC **`Prompt:`** `"Explain the task 4 code snippet, line by line."`

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ##Task 5: Utilizing Databricks Assistant in SQL Editor for Visualization
# MAGIC
# MAGIC Let's leverage Databricks Assistant within the SQL editor to create a table with sample data and visualize it. Databricks Assistant can assist us in generating SQL queries and executing visualizations seamlessly.
# MAGIC
# MAGIC **Instructions:**
# MAGIC
# MAGIC + **Step 1:** Navigate to the SQL editor and locate the Assistant icon.
# MAGIC
# MAGIC
# MAGIC + **Step 2:** Ask Databricks Assistant to generate a SQL query for creating a table named "Demo_table" with sample data for visualization:
# MAGIC
# MAGIC
# MAGIC   **`Prompt:`** `Write query to create table "Lab_table", with some sample data in it for visualization and show the table.`
# MAGIC
# MAGIC + **Step 3:** Import the generated SQL query into the SQL editor and execute it to create the table with the specified sample data.
# MAGIC
# MAGIC + **Step 4:** After creating the table, click on the "`+`" icon within the SQL editor and select the "Visualization" option to initiate the visualization process.

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Clean up Classroom
# MAGIC
# MAGIC Run the following cell to remove lessons-specific assets created during this lesson.

# COMMAND ----------

DA.cleanup()

# COMMAND ----------

# MAGIC %md
# MAGIC # Conclusion
# MAGIC
# MAGIC Through this lab, you will gain hands-on experience with Databricks Assistant and learn how to leverage its functionalities to streamline your coding workflow on the Databricks platform.

# COMMAND ----------

# MAGIC %md
# MAGIC 
&copy; 2024 Databricks, Inc. All rights reserved.<br/>
Apache, Apache Spark, Spark and the Spark logo are trademarks of the 
<a href="https://www.apache.org/">Apache Software Foundation</a>.<br/>
<br/><a href="https://databricks.com/privacy-policy">Privacy Policy</a> | 
<a href="https://databricks.com/terms-of-use">Terms of Use</a> | 
<a href="https://help.databricks.com/">Support</a>