# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning">
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Access DBRX Instruct Model via Marketplace
# MAGIC In this Demo, we will explore how to access the DBRX Instruct model via the Databricks Marketplace. The Databricks Marketplace provides a convenient way to discover and access pre-trained models, including the DBRX Instruct model. We will learn how to locate the DBRX Instruct model in the Marketplace, deploy it to our workspace, and create a serving endpoint for easy integration into our notebooks.
# MAGIC
# MAGIC Once the model is deployed and the serving endpoint is created, we can seamlessly use the DBRX Instruct model within our notebooks for various natural language processing tasks. We will explore how to send requests to the serving endpoint and retrieve responses from the DBRX Instruct model, enabling us to leverage its advanced capabilities for text generation, question-answering, and more.
# MAGIC
# MAGIC **Learning Objectives:**
# MAGIC
# MAGIC By the end of this demonstration, you will learn how to:
# MAGIC
# MAGIC + Access the DBRX Instruct model through the Databricks Marketplace.
# MAGIC + Deploy the DBRX Instruct model
# MAGIC + Create a serving endpoint for the DBRX Instruct model.
# MAGIC + Test the model within a notebook environment using the serving endpoint.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 📌 Requirements
# MAGIC
# MAGIC * To run this notebook, you need to use one of the following Databricks runtime(s): **any**
# MAGIC  
# MAGIC * To be able to use Model Serving, your workspace must be in a [supported region](https://docs.databricks.com/machine-learning/model-serving/index.html#regions).

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Classroom Setup
# MAGIC The first step is to run a setup script that will define the required configuration variables scoped to each user. This script will create a catalog and a schema to be used in the demo.

# COMMAND ----------

# MAGIC %run ./Includes/Classroom-Setup-01

# COMMAND ----------

print(f"Username:          {DA.username}")
print(f"Schema Name:       {DA.schema_name}")
print(f"Working Directory: {DA.paths.working_dir}")
print(f"User DB Location:  {DA.paths.user_db}")
print(f"User Dataset Location:  {DA.paths.datasets}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Access Marketplace Model
# MAGIC
# MAGIC To access the DBRX Model via the Databricks Marketplace, follow these steps:
# MAGIC
# MAGIC * Navigate to the left sidebar menu and click on **Marketplace**.
# MAGIC * Within the Marketplace, locate the Models section.
# MAGIC * Search for the **DBRX Model** (FREE) and click on it to open its overview page.
# MAGIC * **Get Instant Access:** On the overview page, click on **`Get Instant Access`** located at the top right corner.
# MAGIC * Review the terms and conditions presented. If acceptable, agree to them to gain access to the **DBRX Model**.
# MAGIC * After gaining access, click on **`Open`** at the top right corner to view the model in the **catalog**.
# MAGIC * In the catalog window, you can view the **`description`**, **`overview`**, or **`grant permissions`** for the model.
# MAGIC
# MAGIC ![DBRX](http://files.training.databricks.com/images/DBRX Catalog.png)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Serve the Model
# MAGIC
# MAGIC To serve the DBRX Model, follow these steps:
# MAGIC
# MAGIC * In the `catalog` window, locate and click on **Serve the Model** at the top right corner.
# MAGIC * You will be redirected to the **Serving** page, where you can create a `Serving Endpoint`.
# MAGIC * In the **General column**, provide a name for the `Endpoint`.
# MAGIC * Verify the details for DBRX Instruct in the **Served Entities** column.
# MAGIC * **Modify Provisioned Throughput (Optional)**: Modify the **Provisioned Throughput**. By default, it's set to `1200 tokens/second`.
# MAGIC * Once everything is set, click on **`Create`** at the bottom right corner to create the serving endpoint.
# MAGIC ![dbrx](http://files.training.databricks.com/images/DBRX ENDPOINT.png)
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC Once the serving endpoint state is ready, you can perform further model serving tasks and test your endpoint through your notebook.

# COMMAND ----------

# MAGIC %md
# MAGIC ###Test the Model
# MAGIC To test the `DBRX Instruct model` in your notebook, use the following code snippet:

# COMMAND ----------

from langchain.chat_models import ChatDatabricks

# Test Databricks Foundation LLM model
chat_model = ChatDatabricks(endpoint="dbrx_instruct_marketplace", max_tokens = 300)
print(f"Test chat model: {chat_model.predict('What is DBRX Instruct Model?')}")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Clean up Classroom
# MAGIC
# MAGIC Run the following cell to remove lessons-specific assets created during this lesson.

# COMMAND ----------

DA.cleanup()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Conclusion
# MAGIC
# MAGIC By accessing the DBRX Instruct model through the Databricks Marketplace and creating a serving endpoint, you can seamlessly integrate state-of-the-art natural language processing capabilities into your Databricks environment. With easy access to the DBRX model, you can accelerate your AI development projects, leverage advanced text generation and question-answering capabilities, and unlock new possibilities for innovation. Databricks provides a convenient platform for deploying and managing models, enabling you to focus on building transformative AI solutions without the complexity of infrastructure management.

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC &copy; 2024 Databricks, Inc. All rights reserved.<br/>
# MAGIC Apache, Apache Spark, Spark and the Spark logo are trademarks of the 
# MAGIC <a href="https://www.apache.org/">Apache Software Foundation</a>.<br/>
# MAGIC <br/><a href="https://databricks.com/privacy-policy">Privacy Policy</a> | 
# MAGIC <a href="https://databricks.com/terms-of-use">Terms of Use</a> | 
# MAGIC <a href="https://help.databricks.com/">Support</a>