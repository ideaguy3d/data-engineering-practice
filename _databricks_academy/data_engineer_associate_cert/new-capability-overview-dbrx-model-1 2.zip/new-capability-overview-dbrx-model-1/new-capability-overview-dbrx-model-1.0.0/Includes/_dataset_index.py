# Databricks notebook source
# This is an index of all files in this course's datsets and is used to
# validate the local copy of datsets after an install and thus precluding
# the need to reach out to remote repos which may be blocked in some
# workspaces as is common in the Fed and Financial sector's workspaces

remote_files = ["/nyctaxi-yellow/", "/nyctaxi-yellow/2022/", "/nyctaxi-yellow/2022/yellow_tripdata_2022-01.parquet", "/nyctaxi-yellow/README.md"]