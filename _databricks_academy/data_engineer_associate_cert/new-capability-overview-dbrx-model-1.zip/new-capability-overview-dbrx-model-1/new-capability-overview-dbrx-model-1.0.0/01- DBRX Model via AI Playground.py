# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning">
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Demo: Access DBRX Model via AI Playground
# MAGIC
# MAGIC DBRX is a state-of-the-art mixture of experts (MoE) language model trained by Databricks.
# MAGIC
# MAGIC The model outperforms other state-of-the-art language models such as `GPT-3.5-turbo` and `Mixtral-8x7b` on multiple benchmarks, and excels at a broad set of natural language tasks such as: turn-by-turn conversations, text summarization, question-answering, and extraction.
# MAGIC
# MAGIC **DBRX has multiple model versions:**
# MAGIC
# MAGIC * **DBRX Base:** This is the base model which can be fine-tuned on custom data.
# MAGIC
# MAGIC
# MAGIC * **DBRX Instruct:** This is the instruction fine-tuned model which can be used directly for RAG or other use cases.

# COMMAND ----------

# MAGIC %md
# MAGIC ##How to use DBRX Instruct?
# MAGIC
# MAGIC DBRX Instruct is provided as-a-service (pay per token), through a simple API.
# MAGIC
# MAGIC For your GenAI applications, Databricks recommends customizing the model through Retrieval Augmented Generation (RAG), inserting additional content to increase accuracy and reduce hallucinations.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Access the Foundation Model
# MAGIC
# MAGIC 1. Let's start by opening our Model Serving Endpoints
# MAGIC 2. Databricks provides APIs for several Foundation Models. They're available on a Pay-per-token basis.
# MAGIC
# MAGIC       > **`Note:`** `you can also leverage external endpoints (adding governance for models such as Claude, OpenAI...).For more advanced requirements, Databricks makes it easy to Fine Tune and deploy your own LLMs.`

# COMMAND ----------

# MAGIC %md
# MAGIC ## Access the Playground
# MAGIC
# MAGIC Let's explore DBRX Instruct model using Databricks Playground.
# MAGIC
# MAGIC Within the Machine Learning section, locate and click on the AI Playground option. This will open the AI Playground interface, where you can interact with different language models.
# MAGIC > **`Note:`** `Databricks Playground lets you query and compare multiple Model endpoints.`
# MAGIC
# MAGIC
# MAGIC **To use the AI Playground:**
# MAGIC
# MAGIC * Select **Playground** from the left navigation pane under **Machine Learning**.
# MAGIC
# MAGIC * Click on the model name, to review the models available
# MAGIC
# MAGIC  > **Note:** You can select any model, including External Models such as Claude or OpenAI.
# MAGIC
# MAGIC * Let's select the Databricks DBRX Instruct model.
# MAGIC
# MAGIC   >`Under the hood, it's a Mixture of Experts (MoE), providing state-of-the-art performances.`
# MAGIC
# MAGIC * The playground comes with a set of instruction examples. 
# MAGIC     * Click on Document Q&A to see the result.
# MAGIC
# MAGIC ![Playground](https://files.training.databricks.com/images/Screenshot 2024-04-23 at 7.36.16 PM.png)
# MAGIC * The DBRX Instruct model returned the results almost instantly!
# MAGIC
# MAGIC * You can track and compare model performance directly from the playground. DBRX Instruct is blazing fast!

# COMMAND ----------

# MAGIC %md
# MAGIC ### Comparing Models (Optional)
# MAGIC
# MAGIC If desired, you can compare the performance of the DBRX Instruct model with other models available in the AI Playground. Simply select additional models from the Model Serving Endpoints menu and follow the same steps to query and analyze their responses.
# MAGIC
# MAGIC Let's compare DBRX Instruct with another LLM Model:
# MAGIC * Click to split the window and add another prompt.
# MAGIC
# MAGIC * We'll be comparing DBRX Instruct with Llama2 70B.
# MAGIC
# MAGIC   >`Note: we could add around 5 models if we want to the playground!`
# MAGIC
# MAGIC * We synchronized the 2 chats so that we can easily compare the LLM outputs.
# MAGIC
# MAGIC * Add an optional system prompt, write a query and click to send the request to the LLMs!
# MAGIC
# MAGIC * You can quickly compare your 2 models' answer!
# MAGIC
# MAGIC   >`Databricks Playground makes it super easy to compare different model results and helps you pick the one you want to use for your GenAI App!`
# MAGIC ![Playground](https://files.training.databricks.com/images/DBRX AI PLAYGROUND.png)
# MAGIC * Playground also lets you specify more advanced options.
# MAGIC
# MAGIC   >`Click to open the LLM settings. This lets you tweak your LLM parameter and easily evaluate the impact on the answer.`

# COMMAND ----------

# MAGIC %md
# MAGIC ##Conclusion
# MAGIC
# MAGIC DBRX Instruct offers state of the art capabilities with low latencies. By leveraging Databricks Foundation Model and the Playground, you can easily benchmark different LLMs and improve your prompts. This is critical for all your GenAI applications and to increase your RAG performance!
# MAGIC
# MAGIC On top of that, Databricks makes it easy to fine-tune or train custom models.

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC &copy; 2024 Databricks, Inc. All rights reserved.<br/>
# MAGIC Apache, Apache Spark, Spark and the Spark logo are trademarks of the 
# MAGIC <a href="https://www.apache.org/">Apache Software Foundation</a>.<br/>
# MAGIC <br/><a href="https://databricks.com/privacy-policy">Privacy Policy</a> | 
# MAGIC <a href="https://databricks.com/terms-of-use">Terms of Use</a> | 
# MAGIC <a href="https://help.databricks.com/">Support</a>